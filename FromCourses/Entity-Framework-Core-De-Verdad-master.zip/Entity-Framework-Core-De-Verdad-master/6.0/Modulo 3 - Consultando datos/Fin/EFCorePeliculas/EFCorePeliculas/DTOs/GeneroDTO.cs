﻿namespace EFCorePeliculas.DTOs
{
    public class GeneroDTO
    {
        public int Identificador { get; set; }
        public string Nombre { get; set; }
    }
}
