﻿namespace EFCorePeliculas.DTOs
{
    public class PeliculaActorCreacionDTO
    {
        public int ActorId { get; set; }
        public string Personaje { get; set; }
    }
}
