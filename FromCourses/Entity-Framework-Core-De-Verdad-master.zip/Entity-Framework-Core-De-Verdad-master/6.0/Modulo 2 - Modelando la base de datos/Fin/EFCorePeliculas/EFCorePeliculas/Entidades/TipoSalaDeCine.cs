﻿namespace EFCorePeliculas.Entidades
{
    public enum TipoSalaDeCine
    {
        DosDimensiones = 1,
        TresDimensiones = 2,
        CXC = 3
    }
}
