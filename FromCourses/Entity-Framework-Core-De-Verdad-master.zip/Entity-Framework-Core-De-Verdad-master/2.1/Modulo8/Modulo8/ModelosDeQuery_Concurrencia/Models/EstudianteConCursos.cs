﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ModelosDeQuery_Concurrencia.Models
{
    public class EstudianteConCursos
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public int CantidadDeCursos { get; set; }
    }
}
