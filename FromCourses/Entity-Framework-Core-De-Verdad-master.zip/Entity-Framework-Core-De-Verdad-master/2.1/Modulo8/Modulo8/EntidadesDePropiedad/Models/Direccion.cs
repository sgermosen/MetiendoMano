﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EntidadesDePropiedad.Models
{
    public class Direccion
    {
        public string Street { get; set; }
        public string City { get; set; }
    }
}
