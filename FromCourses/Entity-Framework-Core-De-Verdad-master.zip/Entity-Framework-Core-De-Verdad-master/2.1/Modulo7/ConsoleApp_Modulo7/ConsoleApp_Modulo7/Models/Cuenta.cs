﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ConsoleApp_Modulo7.Models
{
    public class Cuenta
    {
        public decimal Fondos { get; set; }
    }
}
