﻿namespace PeliculasAPI.Helpers
{
    internal class CreateMap<T>
    {
    }
}