﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebApiModulo4.Services
{
    public interface IClaseB
    {
        void HacerAlgo();
    }
}
