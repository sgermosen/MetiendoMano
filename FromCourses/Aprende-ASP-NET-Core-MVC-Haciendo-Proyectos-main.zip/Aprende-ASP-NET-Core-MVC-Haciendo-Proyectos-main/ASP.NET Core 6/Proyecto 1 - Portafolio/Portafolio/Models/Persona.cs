﻿namespace Portafolio.Models
{
    public class Persona
    {
        public string Nombre { get; set; }
        public int Edad { get; set; }
    }
}
