﻿namespace Portafolio.Models
{
    public class HomeIndexViewModel
    {
        public IEnumerable<Proyecto> Proyectos { get; set; }
        public EjemploGUIDViewModel EjemploGUID_1 { get; set; }
        public EjemploGUIDViewModel EjemploGUID_2 { get; set; }
    }
}
