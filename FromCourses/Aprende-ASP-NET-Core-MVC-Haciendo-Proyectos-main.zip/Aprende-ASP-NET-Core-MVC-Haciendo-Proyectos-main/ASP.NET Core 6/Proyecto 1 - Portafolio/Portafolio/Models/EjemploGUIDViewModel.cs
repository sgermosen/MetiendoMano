﻿namespace Portafolio.Models
{
    public class EjemploGUIDViewModel
    {
        public Guid Transitorio { get; set; }
        public Guid Delimitado { get; set; }
        public Guid Unico { get; set; }
    }
}
