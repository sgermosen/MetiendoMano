CREATE ROLE db_executor;

GRANT EXECUTE TO db_executor;
