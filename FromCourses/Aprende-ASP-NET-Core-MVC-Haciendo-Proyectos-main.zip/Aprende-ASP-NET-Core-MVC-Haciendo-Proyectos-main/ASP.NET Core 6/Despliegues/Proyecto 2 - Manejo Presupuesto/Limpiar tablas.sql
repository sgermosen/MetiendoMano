DELETE Transacciones;
DELETE Cuentas;
DELETE TiposCuentas;
DELETE Categorias;
DELETE Usuarios;
