﻿using CursoLINQ;

Console.WriteLine("El código de ejemplo se encuentra en las respectivas carpetas");