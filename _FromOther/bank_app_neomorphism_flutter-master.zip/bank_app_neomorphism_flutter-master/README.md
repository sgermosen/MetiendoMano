# Bank app concept in a neomorphism style. Made with Flutter

<img src="https://cdn.dribbble.com/users/2049996/screenshots/9158186/media/b981805434cc8d9f72bbb527cb61ec6c.png">

## ScreenShots:
<img  height="480px" style="margin-right:10px;" src="screenshots/1.png">&nbsp;&nbsp;<img height="480px" style="margin-right:10px;"  src="screenshots/2.png">

## Original design prototype in Dribble by Mathis Freudenberger
https://dribbble.com/mathisfr_design
 
### Show some :heart: and star the repo to support the project or :smile:[Follow Me](https://github.com/marcioquimbundo).Thanks!
[![GitHub stars](https://img.shields.io/github/stars/marcioquimbundo/flutter_card_wallet.svg?style=social&label=Star)](https://github.com/MarcioQuimbundo/flutter_card_wallet) [![GitHub forks](https://img.shields.io/github/forks/marcioquimbundo/flutter_card_wallet.svg?style=social&label=Fork)](https://github.com/MarcioQuimbundo/flutter_card_wallet/fork) [![GitHub watchers](https://img.shields.io/github/watchers/marcioquimbundo/flutter_card_wallet.svg?style=social&label=Watch)](https://github.com/MarcioQuimbundo/flutter_card_wallet) [![GitHub followers](https://img.shields.io/github/followers/marcioquimbundo.svg?style=social&label=Follow)](https://github.com/MarcioQuimbundo/)  
