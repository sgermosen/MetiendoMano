void main() {
  
//   	Números
  int empleados = 10;
  double pi = 3.141592;
  var numero = 1.0;
  
  print( '$empleados - $pi - $numero' );
  
//   String - Cadenas de caracteres
  String nombre = 'Tony';
  print(nombre);
  print(nombre[0]);
  print(nombre[ nombre.length - 1 ]);
  
}