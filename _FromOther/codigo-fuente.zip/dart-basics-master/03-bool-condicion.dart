void main() {
  
  
  bool activado = true;
  print(activado);
  
  
  if ( !activado ) {
    print('El motor esta funcionando');
  } else {
    print('Está apagado');
  }
  
  
  
}