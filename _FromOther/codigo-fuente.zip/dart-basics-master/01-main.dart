void main() {
  
  /*
  print('Hola Mundo');
  asdasd
  asd
  a
  sdasd
  */
  
  String nombre;

  print('Hola $nombre');
  
}