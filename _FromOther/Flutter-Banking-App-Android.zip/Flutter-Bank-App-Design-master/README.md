# Flutter-Bank-App-Design
Bank App Design UI development using Flutter

Design inspiration - https://dribbble.com/shots/6081118-Bank-App-Concept/attachments

![alt text](https://raw.githubusercontent.com/aravindrajpalani/Flutter-Bank-App-Design/master/bankapp.gif)


