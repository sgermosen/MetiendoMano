package com.example.mobile_banking_neomorphism_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
