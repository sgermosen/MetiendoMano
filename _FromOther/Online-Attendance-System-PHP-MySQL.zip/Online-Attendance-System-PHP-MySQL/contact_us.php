<?php
    include './Database/Controler.php';
    include 'role.php';
?>

<h2>Contact Details</h2> 
<div class="row">
          <div class="col-md-12">
          <div class="panel panel-default">
          <div class="panel-body">
          <div class="table-responsive">
          
         <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                   <td><center><br><img src="img/student.png" height="20%" width="30%" style="border-radius:50%;"></center><br>
                        <b><h3><center>J.Vetrivel Pandian</center></h3></b>
                        <h4><center><b>Email:</b>vetbossel@gmail.com</center>
                        <h4><center><b>Contact Number:</b>8940379384</center>
                   </td>
                   
          </table>
<?php
include 'footer.php';
?>
