# Beerstory

**What was the beer I drank yersteday again...?**
Don't forget it anymore with Beerstory ! Indeed, Beerstory is a little that allows you to save your favorite beers. You can also add a lot of other info like the degree, the photo, a rating, tags that allow you to find it back easier, its price in the bars you like, and more !

Beerstory goes beyond saving your favorite beers because it also allows you to save your favorite beers, to have a beer history, etc...

<img src="https://github.com/Skyost/Beerstory/blob/master/screenshots/1.png" height="500" alt="Screenshot 1"> <img src="https://github.com/Skyost/Beerstory/blob/master/screenshots/2.png" height="500" alt="Screenshot 2">

[View gallery](https://github.com/Skyost/Beerstory/tree/master/screenshots)

## Features

Here are some highlights :

* Lightweight.
* Open-source.
* Save your beers, your bars and even your consumption.
* More !

## So what are your waiting for ?

You want a beer library in your pocket ? Then install this app !

* [Google Play](https://play.google.com/store/apps/details?id=fr.skyost.beerstory)
* [App Store](https://itunes.apple.com/app/id1491556149)

## Contributions

You have a lot of options to contribute to this project ! You can :

* [Fork it](https://github.com/Skyost/Beerstory/fork) on Github.
* [Submit](https://github.com/Skyost/Beerstory/issues/new/choose) a feature request or a bug report.
* [Donate](https://paypal.me/Skyost) to the developer.
* [Watch a little ad](https://www.clipeee.com/creator/skyost) on Clipeee.
