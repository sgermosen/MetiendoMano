## [2.0.0]

- major update
- `var youtube = new FlutterYoutube()` to `FlutterYoutube.`;

## [1.3.5]

- iOS Crash Fixes


## [1.2.0]

- Only use `var youtube = new FlutterYoutube()`;

## [1.1.6]

- Merged PR #36 and #32

## [1.1.5]

- Support Android X.
- Breaking change. Migrate from the deprecated original Android Support Library to AndroidX. This shouldn't result in any functional changes, but it requires any Android apps using this plugin to also migrate if they're using the original support library.

## [1.1.4]

- Broken ';' fixed

## [1.1.3]

## [1.1.2]

- Video play complete listener Crash fixed

## [1.1.1]

- Youtube embed URL
- Video AutoPlay
- Video play complete listener

## [1.0.1]

- Bug fixes (video pause when screen rotated)

## [1.0.0]

- iOS Support added

## [0.1.1] - 17-04-2018

- Minor BugFixes

## [0.1.1] - 17-04-2018

- BugFixes

## [0.1.0] - 17-04-2018

- Initial Release
- Play youtube video using url or by video id
- setFullScreen
