#import <Flutter/Flutter.h>

@interface FlutterYoutubePlugin : NSObject<FlutterPlugin>
@end
