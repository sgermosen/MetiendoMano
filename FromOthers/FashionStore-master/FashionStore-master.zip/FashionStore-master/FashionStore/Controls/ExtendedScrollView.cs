﻿using System;
using Xamarin.Forms;

namespace FashionStore.Controls
{
    public class ExtendedScrollView : ScrollView
    {
        public bool HasTopPadding { get; set; }
        public ExtendedScrollView()
        {
        }
    }
}
