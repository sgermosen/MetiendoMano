﻿using System;
namespace FashionStore.Models
{
    public enum Category
    {
        Tshirt,
        Pants,
        Hoodies

    }
}
