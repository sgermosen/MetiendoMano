﻿using System;
using System.Collections.Generic;
using FashionStore.Components;
using Xamarin.Forms;

namespace FashionStore.Views
{
    public partial class ProductsPage : ContentPage
    {
        public ProductsPage()
        {
            NavigationPage.SetHasNavigationBar(this, false);

            InitializeComponent();

        }

    }
}
