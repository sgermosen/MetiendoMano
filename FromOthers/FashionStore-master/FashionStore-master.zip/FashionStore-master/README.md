# FashionStore

<img src="images/FashionStore.gif" Width="400" />
<img src="images/FasionStoreAndroid.gif" Width="400" />

### Platforms

iOS.
Android.

## Copyright and license

Code released under the [MIT license](https://opensource.org/licenses/MIT).