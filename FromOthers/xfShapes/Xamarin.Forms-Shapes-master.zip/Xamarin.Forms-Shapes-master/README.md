# Xamarin.Forms Shapes
Making use of the Xamarin.Forms Shapes and Xamarin.Forms MediaElement to create an elegant login page in xamarin forms.

You can watch the video here ➤ https://youtu.be/X3ZND30zI_A


![alt text](https://github.com/devcrux/Xamarin.Forms-Shapes/blob/master/ShapesAds.gif) 
