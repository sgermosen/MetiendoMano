﻿namespace XFFurniture.Interfaces
{
    public interface IStatusBarStyle
    {
        void ChangeTextColor(bool darkContent = false);
    }
}
