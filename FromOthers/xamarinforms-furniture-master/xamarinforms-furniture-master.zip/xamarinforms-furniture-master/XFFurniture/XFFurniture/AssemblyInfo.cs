using Xamarin.Forms;
using Xamarin.Forms.Xaml;

[assembly: XamlCompilation(XamlCompilationOptions.Compile)]
[assembly: ExportFont("Montserrat-Regular.ttf", Alias = "FontMontserratRegular")]
[assembly: ExportFont("Montserrat-Bold.ttf", Alias = "FontMontserratBold")]
[assembly: ExportFont("Montserrat-SemiBold.ttf", Alias = "FontMontserratSemiBold")]
[assembly: ExportFont("Montserrat-Medium.ttf", Alias = "FontMontserratMedium")]
[assembly: ExportFont("fontello.ttf", Alias = "FontFontello")]