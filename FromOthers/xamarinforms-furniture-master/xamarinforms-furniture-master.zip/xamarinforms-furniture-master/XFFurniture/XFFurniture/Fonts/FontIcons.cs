﻿namespace XFFurniture.Fonts
{
    public static class FontIcons
    {
        public const string Search = "\uE800";
        public const string Close = "\uE801";
        public const string HeartOutline = "\uE802";
    }
}
