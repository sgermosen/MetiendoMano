﻿namespace Instagram
{	
	public enum Stacks
	{
		Authentication,
		Main
	}

	public enum AuthenticationViews
	{
		Welcome,
		Login
	}

	public enum MainViews
	{
		Feed
	}
}
