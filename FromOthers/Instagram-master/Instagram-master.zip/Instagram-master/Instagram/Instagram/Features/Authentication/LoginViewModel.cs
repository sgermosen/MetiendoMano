﻿namespace Instagram.ViewModel
{
	/// <summary>
	/// This is a standard ViewModel.
	/// </summary>
	public class LoginViewModel : Exrin.Framework.ViewModel
	{
		
	}
}
