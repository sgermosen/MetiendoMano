A Pen created at CodePen.io. You can find this one at https://codepen.io/junebug12851/pen/mJZNqN.

 A customizable and theme-able progress bar in the shape of a bubble with constantly sloshing water inside of it. This demo features 3 colors, red, orange, and green depending on the percentage and a textbox to smoothly change the value. Code Modified and Inspired from Jamie Dixon's pen