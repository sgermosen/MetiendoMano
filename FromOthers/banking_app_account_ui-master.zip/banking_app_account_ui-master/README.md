# banking_app_account_ui

Another episode of flutter thursday.

[See entire series here](https://medium.com/@afegbua/flutter-thursday-series-9564d04e63a7), 
## Getting Started

```
git clone https://github.com/shubie/banking_app_account_ui.git

cd banking_app_account_ui

flutter packages get

flutter run

```

