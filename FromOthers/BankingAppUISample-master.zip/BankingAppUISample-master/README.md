# BankingAppUISample

<p align="center">

<img src="https://github.com/LeomarisReyes/BankingAppUISample/blob/master/Images/BPrincipanlImageIOS.png" height="540" width="720"/>
</p>

<p>UI replicated in Xamarin Forms. For more information about, you can enter to my blog https://askxammy.com </p>
⚠ Design obteined from Dribble. -> https://dribbble.com/shots/9242842-Banking-App-Concept
