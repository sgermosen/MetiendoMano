﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace BankingAppUISample.Views
{
    public partial class BankingProfilePage : ContentPage
    {
        public BankingProfilePage()
        {
            InitializeComponent();
        }
    }
}
