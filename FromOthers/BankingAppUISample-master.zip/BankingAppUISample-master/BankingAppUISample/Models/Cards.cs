﻿using System;
namespace BankingAppUISample.Models
{
    public class Cards
    {
        public string CardImage             { get; set; }
        public string CardBussinessCategory { get; set; }
        public string CardNumber            { get; set; }
        public string CardType              { get; set; }
        public string CardExpirationDate    { get; set; }
    }
}
