﻿using System;
namespace BankingAppUISample.Models
{
    public class History
    {
        public string Picture { get; set; }
        public string Name    { get; set; }
        public string Price   { get; set; }    
        public string Date    { get; set; } 
    }
}
