﻿
$(document).ready(function () {

    //var detalle = "<br><br>";
    //var theRealUrl;
 
    $("input,textarea,select").attr("disabled", true);

    //$("#BtnPrintA4").click(function () {

    //    var url = '@Url.Action("AnaliticalSheetA4", "Patients",new {area="Medicals"})';

    //     url += "/" + $("#AnalyticalSheetId").val();

    //    var win = window.open(url);

    //    if (win) {
    //        //Browser has allowed it to be opened
    //        win.focus();
    //    } else {
    //        //Browser has blocked it
    //        alert("Porfavor, debes permitir que se abran las ventanas emergentes o el reporte no va a salir :'( ");
    //    }
    //    // window.location.href = url;
    //});
 

});
