﻿
$(document).ready(function () {

   // var detalle = "<br><br>";
   // var theRealUrl;
 
    $("input,textarea,select").attr("disabled", true);
    
    //$('#BtnPrint').click(function () {
        
    //    var afection = $('#Affections').val();
    //    afection = afection.replace(/\n/g, "<br>");
    //    afection = afection.replace(/ /g, '\u00a0');
    //    afection = "<span>" + afection + "</span>";

    //    var recomentation = $('#Recomendations').val();
    //    recomentation = recomentation.replace(/\n/g, "<br>");
    //    recomentation = recomentation.replace(/ /g, '\u00a0');
    //    recomentation = "<span>" + recomentation + "</span>";

    //    printRecibe(afection, recomentation);

    //    var url = theRealUrl;
    //    url = url + "&body=" + encodeURIComponent(detalle);
    //    var win = window.open(url);

    //    if (win) {
    //        //Browser has allowed it to be opened
    //        win.focus();
    //    } else {
    //        //Browser has blocked it
    //        alert("Porfavor, debes permitir que se abran las ventanas emergentes o el reporte no va a salir :'( ");
    //    }

    //});

    //function printRecibe (affection, recomendation) {

    //     detalle = "<br><br>";

    //    detalle += " Yo: <b>" + $('#DoctorText').val()   + "</b>";
    //    if ($('#Exequartur').val() != "") {
    //        detalle += ", exequatur: <b>" + $('#Exequartur').val() + "</b>, " + $('#Cmd').val() +  " <br>";
    //    }
    //    detalle += "<br>";
    //    detalle += " Certifico haber examinado a: <b>" + $('#PatientName').val()   + "</b> <br>";

    //    detalle += "<br>";
    //    detalle += " Quien presenta: <b>" + affection + "</b>    <br>";
    //    detalle += "<br>";
    //    detalle += " Por lo que recomiendo: <b>" + recomendation + "</b>    <br>";
    //    detalle += "<br>";
    //    detalle += "<br>";
    //    detalle += "<br>";
    //    detalle += " Expido la presente Certificación en: " + $('#Place').val()    + "    <br>";

    //    detalle += " Fecha: " + $('#MedicalCertificateDate').val()    + "    <br>";
    //    detalle += "<br><br><br><br>  ";
    //    detalle += "<br><br><br><br>  ";
    //    detalle += "<center> Firma Medico:___________________________________</center>";
         

    //};

 
 

});
