﻿
$(document).ready(function () {

    //var detalle = "<br><br>";
   // var theRealUrl;
 
    $("input,textarea,select").attr("disabled", true);
    
});
