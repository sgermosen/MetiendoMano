# Hospital-Management-System
HMS is a website for management for the hospital including Ambulances management. The main objective of the HMS is is to help hospital administrator to have an electronic system instead of manual system so that  the data management will be more easy, secure and fast. For this purpose we are using .Net core mvc language to complete this project.
