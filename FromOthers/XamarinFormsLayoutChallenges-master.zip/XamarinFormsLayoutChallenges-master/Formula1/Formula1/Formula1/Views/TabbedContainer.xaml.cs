﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace Formula1
{
    public partial class TabbedContainer : TabbedPage
    {
        public TabbedContainer()
        {
            InitializeComponent();
        }
    }
}
