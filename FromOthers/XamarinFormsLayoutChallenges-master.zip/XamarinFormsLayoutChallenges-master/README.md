# Xamarin.Forms UI's don't have to suck

Xamarin.Forms is a crazy productive framework for build cross platform apps.  However, straight out of the box you might find your User Interfaces a bit bland. A good understanding of the layout system (and a good graphic designer) are really going to help you make your UI's awesome.  (or at least not suck)

In this repo, I'm going to recreate some nice looking UI's that I find around the web (places like [Dribbble](http://dribbble.com)) with Xamarin.Forms.



