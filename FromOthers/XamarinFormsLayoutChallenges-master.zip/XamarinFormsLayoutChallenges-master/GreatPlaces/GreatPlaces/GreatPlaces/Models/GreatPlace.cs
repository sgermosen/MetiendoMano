﻿using System;
namespace GreatPlaces
{
	public class GreatPlace
	{
		public string Title { get; set; }
		public string Handle { get; set; }
		public int ViewCount { get; set; }
		public string HeroImage { get; set; }
		public string ProfileImage { get; set; }
	}
}
