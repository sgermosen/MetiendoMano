# Animated Xamarin.Forms Expander
Let's make use of the Xamarin.Forms Expander to create an animated expandable list in Xamarin Forms.

You can watch the video here ➤ https://youtu.be/ndF5we5_Ijw


![alt text](https://devcrux.com/wp-content/uploads/animatedexpander.gif) 
