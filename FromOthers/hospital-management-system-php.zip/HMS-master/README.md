<p align="center">
	<img src="https://img.shields.io/github/license/kabirkhyrul/HMS?style=flat-square">
	<img src="https://img.shields.io/github/issues/kabirkhyrul/HMS?style=flat-square">
	<img src="https://img.shields.io/github/watchers/kabirkhyrul/HMS?style=flat-square">
	<img src="http://hits.dwyl.io/kabirkhyrul/HMS?style=flat-square">
   <img src="https://img.shields.io/github/languages/code-size/kabirkhyrul/HMS?style=flat-square">	
	<img src="https://img.shields.io/github/downloads/kabirkhyrul/HMS/total?style=flat-square">	
	<img src="https://img.shields.io/github/stars/kabirkhyrul/HMS?style=flat-square">
	<img src="https://img.shields.io/github/tag-date/kabirkhyrul/HMS?style=flat-square">
	
	
</p>

This is a Startup Project. May contain Bugs.

# INSTALLATION

---

<ol>
<li>Download and Unzip files To Localhost Folder.</li>
<li>Import Database.</li>
</ol>

Run Project Through Xampp and Browser.


# Demo
---
https://www.kabir.infantinventory.com/hms/
