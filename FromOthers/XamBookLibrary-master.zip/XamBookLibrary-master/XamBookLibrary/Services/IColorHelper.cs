﻿using System;
using Xamarin.Forms;

namespace XamBookLibrary.Services
{
    public interface IColorHelper
    {
        string GetColor(string fileName);
    }
}
