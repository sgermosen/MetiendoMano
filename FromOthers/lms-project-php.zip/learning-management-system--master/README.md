# (OpenSourceLms) Simple LMS

All Requirements are met plus the bounus of the bounus:

 * crud operation for ( categories - courses -materials)
 * users can view , download courses material and comment on them
 * social media sharing and login
 * rss chanel for courses
 * full responsive website
 

### Developers:

 * [Salama Ashoush](https://github.com/salamaashoush)
 * [Mohamed Habib](https://github.com/muhammad-habib)
 * [Hanan Hafez](https://github.com/hananhafez) 
 * [Khaled Sabah](https://github.com/khaledsabbah)

### [View on Heroku](http://opensourcelms.herokuapp.com) 
#####Big Thanks for [Islam Askr](https://github.com/islamaskar) for giving us time to finish
