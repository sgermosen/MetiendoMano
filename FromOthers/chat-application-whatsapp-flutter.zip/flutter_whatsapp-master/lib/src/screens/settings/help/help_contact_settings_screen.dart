import 'package:flutter/material.dart';

class HelpContactSettingsScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('TITLE'),
      ),
      body: Center(
        child: Text('TODO'),
      ),
    );
  }

}