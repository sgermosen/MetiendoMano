import 'package:flutter/material.dart';

class StatusPrivacyScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('StatusPrivacyScreen'),
      ),
      body: Center(
        child: Text('TODO'),
      ),
    );
  }

}