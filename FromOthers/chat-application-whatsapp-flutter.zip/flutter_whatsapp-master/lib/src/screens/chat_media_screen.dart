import 'package:flutter/material.dart';

class ChatMediaScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('ChatMediaScreen'),
      ),
      body: Center(
        child: Text('TODO'),
      ),
    );
  }

}