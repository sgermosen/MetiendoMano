import 'package:flutter/material.dart';

class NewChatGroupScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('NewChatGroupScreen'),
      ),
      body: Center(
        child: Text('TODO'),
      ),
    );
  }

}