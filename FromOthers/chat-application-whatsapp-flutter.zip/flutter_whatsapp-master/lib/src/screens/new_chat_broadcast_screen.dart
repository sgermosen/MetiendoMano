import 'package:flutter/material.dart';

class NewChatBroadcastScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('NewChatBroadcastScreen'),
      ),
      body: Center(
        child: Text('TODO'),
      ),
    );
  }

}