import 'package:flutter/material.dart';

class NewCallScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('NewCallScreen'),
      ),
      body: Center(
        child: Text('TODO'),
      ),
    );
  }

}