﻿using System;
namespace KickassUI.Banking.PageModels
{
    public class OverviewPageModel : BasePageModel
    {
    }
}
