﻿using System;
using FreshMvvm;

namespace KickassUI.Banking.PageModels
{
    public class BasePageModel : FreshBasePageModel
    {
        
    }
}
