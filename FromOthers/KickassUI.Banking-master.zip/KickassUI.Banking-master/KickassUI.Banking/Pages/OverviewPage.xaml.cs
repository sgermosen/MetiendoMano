﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace KickassUI.Banking.Pages
{
    public partial class OverviewPage : BasePage
    {
        public OverviewPage()
        {
            InitializeComponent();
        }
    }
}
