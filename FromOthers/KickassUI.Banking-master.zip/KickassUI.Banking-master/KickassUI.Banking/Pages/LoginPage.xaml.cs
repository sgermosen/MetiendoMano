﻿using System;
using System.Collections.Generic;

using Xamarin.Forms;

namespace KickassUI.Banking.Pages
{
    public partial class LoginPage : BasePage
    {
        public LoginPage()
        {
            InitializeComponent();
        }
    }
}
