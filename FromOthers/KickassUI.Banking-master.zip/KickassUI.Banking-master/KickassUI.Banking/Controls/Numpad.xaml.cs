using System;
using Xamarin.Forms;


namespace KickassUI.Banking.Controls
{
    public partial class Numpad : Grid
    {
        public Numpad()
        {
            InitializeComponent();
        }
    }
}