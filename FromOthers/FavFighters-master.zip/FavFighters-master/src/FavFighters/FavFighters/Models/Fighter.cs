﻿namespace FavFighters.Models
{
    public class Fighter
    {
        public string Name { get; set; }
        public string Tier { get; set; }
        public string Image { get; set; }
        public string Category { get; set; }
    }
}