<style type="text/css">
.center {text-align: center; margin-left: auto; margin-right: auto; margin-bottom: auto; margin-top: auto;}    
</style>
<?php include 'menu.php';?>
<div class="container">
  <div class="row">
    <div class="span12">
      <div class="hero-unit center">
          <h1 style="margin-top:12%"><font face="Tahoma" color="red">Oops... Page not found</font></h1>
          <br />
          <p>The page you requested could not be found, either contact your webmaster or try again. Use your browsers <b>Back</b> button to navigate to the page you have prevously come from</p>
          <p><b>Or you could just press this neat little button:</b></p>
          <a href="../Online-Admission/" class="btn btn-large btn-success"><i class="icon-home icon-white"></i> Take Me Home</a>
      </div>
  </div>
</div>
