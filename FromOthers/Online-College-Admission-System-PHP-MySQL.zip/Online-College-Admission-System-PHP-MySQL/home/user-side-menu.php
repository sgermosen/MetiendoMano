<style>
.a-color{
  text-decoration-color: black !important;
  text-align: center;
}
</style>
<section id="main">
  <div class="container">
    <div class="row">
      <div class="col-md-3">
       <div class="list-group">
        <p href="#" class="list-group-item main-color-bg a-color navbar-nuvcolor" style="color: white !important;">
          <span class="glyphicon glyphicon-cog" aria-hidden="true" style="color: white !important;"></span> Sidemenu</p>
          <a href="index.php" class="list-group-item"><span class="glyphicon glyphicon-list-alt" aria-hidden="true"></span> Home <span class="badge"></span></a>
          <a href="profile.php" class="list-group-item"><span class="glyphicon glyphicon-pencil" aria-hidden="true"></span> Profile<span class="badge"></span></a>
          <a href="educational_details.php" class="list-group-item"><span class="glyphicon glyphicon-book" aria-hidden="true"></span> Educational Details <span class="badge"></span></a>
          <a href="educational_details_be.php" class="list-group-item"><span class="glyphicon glyphicon-book" aria-hidden="true"></span> Educational Details (B.E) <span class="badge"></span></a>
          <a href="apply.php" class="list-group-item"><span class="glyphicon glyphicon-user" aria-hidden="true"></span> Apply<span class="badge"></span></a>
          <a href="logout.php" class="list-group-item"><span class="glyphicon glyphicon-log-out" aria-hidden="true"></span> Logout <span class="badge"></span></a>
        </div>
      </div>
