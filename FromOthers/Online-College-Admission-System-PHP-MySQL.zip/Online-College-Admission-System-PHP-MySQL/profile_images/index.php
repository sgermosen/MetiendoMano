<?php
			echo "<script language='javascript'>alert('You cannot access this directory');
			window.location.href='/Admission/';
			 </script>";
?>
