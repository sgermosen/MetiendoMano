﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Introduccion.Entities
{
    public class Cuenta
    {
        public decimal Fondos { get; set; }
    }
}
