<?php 

if(!empty($_POST['update'])){
$f=$_REQUEST['mystudent'];
echo $f."o sokhina ";
}

?>